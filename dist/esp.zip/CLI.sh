#!/bin/bash

computephi Arch2_crystal.ARM_10490-tk.pdb Arch2_crystal.ARM_10490-tk.xyz ar2_-155.xyz ar2_-98.xyz ar2_-155.out ar2_-98.out > PHI.dat

